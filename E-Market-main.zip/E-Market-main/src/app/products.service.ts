import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  getAllProducts() {
    throw new Error('Method not implemented.');
  }

  constructor() { }
}
