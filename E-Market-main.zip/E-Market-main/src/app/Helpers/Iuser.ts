export interface Iuser {
  id:string;
  name:string;
  email:string;
  password:string;
  age:number;
  role:string
}
